{
    "header": 
    {

        "project": "SeaCloudsProject",
        "component": "NURO/maintenance",
        "milestone": "M30",
        "sourceversion": "D6.3.3",
        "release": "2015-03-30",
    },
    "result": 
    {
        "analytics": [],
        "guides": [ ]

    },
    "database1": 
    {

        "_INFO": "NURO/maintenance",
        "status": "maintenance",
    },
    "request_analytics": {
        "10seconds": {},
        "minute":  {},
        "hour":  {},
        "day":  {},
        "week":  {},
    },
    "debug": []
}