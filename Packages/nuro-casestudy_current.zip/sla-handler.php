<?php

// ****************************************************************************
/**
 * Nurogames SeaClouds Casestudy sla-handler
 *
 * sla-handler.php
 *
 * @author      Christian Tismer, Nurogames GmbH
 * 
 * @copyright   Copyright (c) 2016, Nurogames GmbH
 * 
 * This is an exemplary sla-handler plugin
 * 
 */
// ****************************************************************************

$kEffector->result->handler = 'SLA-handler';

?>